package checkout5;

public interface MemberType {
    int discount(int totalPrice);
}
